50 m² NAMO 3D MODELIS – V4, PBR TEKSTŪROS

Ši versija išsaugo atskirą namo išorės modelį ir stogo neturintį patalpų išplanavimą, bet įdeda fiziškai pagrįstas (PBR) medžio, grafito metalo, žalios vertikalios fasado dangos, betono, trinkelių, asfalto ir žolės tekstūras.

HTML failas turi įdėtus GLB modelius, todėl pakanka įkelti vieną HTML failą į GitHub saugyklą ir atidaryti per GitHub Pages. Reikalingas internetas model-viewer bibliotekai iš CDN.

Modelis koncepcinis; geometriją ir tikslius matmenis reikia sutikrinti su architektūriniu projektu. Tekstūros didina medžiagų natūralumą, tačiau tai nėra fotogrametrinis skenavimas ar galutinis architektūrinis vizualizavimo renderis.
