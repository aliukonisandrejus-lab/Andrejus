50 m² NAMO 3D MODELIS – V4

Atidarykite namas_50m2_3D_turas_v3.html. HTML faile abu GLB modeliai įterpti tiesiogiai, todėl HTML peržiūrai nereikia papildomų vaizdų failų. Reikalingas interneto ryšys, nes 3D peržiūros biblioteka įkeliama iš CDN.

Valdikliai: Išorė / Patalpų išplanavimas / fasado krypčių pasirinkimas / įėjimo ir terasos priartinimas / automatinis sukimasis.

GLB failai pakete skirti tolesniam modeliavimui ir redagavimui. Modelis koncepcinis; tikslios statybinės dimensijos turi būti suderintos pagal architektūrinį projektą.
